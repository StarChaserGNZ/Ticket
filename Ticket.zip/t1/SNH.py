# uncompyle6 version 3.9.0
# Python bytecode version base 3.7.0 (3394)
# Decompiled from: Python 3.7.11 (default, Jul 27 2021, 09:42:29) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: snhopInList1.47.py
# Compiled at: 1995-09-28 00:18:56
# Size of source mod 2**32: 538968336 bytes
"""
 *
 * Copyright (C) 2022, C.S. Yuen (imobo), All rights reserved.
 * Do not copy, distribute, or modify without permission of the author.
 *
 * Main change in version 1.47: bid function update (added referer in header when trying to access to historical bid data) 
 *
 *
"""
import hashlib, configparser, re, os, json, random, time, datetime, requests, _thread as thread
from bs4 import BeautifulSoup
from urllib3.exceptions import InsecureRequestWarning

requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)
ROOT_DIR = os.getcwd()
LOG_PATH = os.path.join(ROOT_DIR,'log.txt')
COOKIES_PATH = os.path.join(ROOT_DIR,'cookies.txt')
CONFIGS_PATH = os.path.join(ROOT_DIR,'config.ini')
LOOP_DELAY = 1
TIMEOUT = 30
USE_PROXIES = 0
FIXED_PROXIES = {}
LOGIN_HEADERS = {
    'Origin': "https://user.48.cn",
    'Referer': "https://user.48.cn/Login/index.html?return_url=https://shop.48.cn/Account",
    'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18363",
    'Accept': "application/json, text/javascript, */*; q=0.01",
    'Accept-Language': "en-GB,en;q=0.8,zh-Hans-CN;q=0.6,zh-Hans;q=0.4,ja;q=0.2",
    'Content-Type': "application/x-www-form-urlencoded; charset=UTF-8",
    'X-Requested-With': "XMLHttpRequest",
    'Accept-Encoding': "gzip, deflate, br",
    'Host': "user.48.cn",
    'Content-Length': "80",
    'Connection': "Keep-Alive",
    'Cache-Control': "no-cache"}
SHOP_HEADERS = {
    'Accept': "*/*",
    'Accept-Encoding': "gzip, deflate, br",
    'Accept-Language': "zh-CN,zh;q=0.9,en-GB;q=0.8,en;q=0.7,zh-TW;q=0.6,ja;q=0.5",
    'Connection': "keep-alive",
    'Host': "shop.48.cn",
    'Sec-Fetch-Dest': "script",
    'Sec-Fetch-Mode': "no-cors",
    'Sec-Fetch-Site': "same-site",
    'User-Agent': "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36"}
M_HEADERS = {
    'Accept': "*/*",
    'Accept-Encoding': "gzip, deflate, br",
    'Accept-Language': "zh-CN,zh;q=0.9,en-GB;q=0.8,en;q=0.7,zh-TW;q=0.6,ja;q=0.5",
    'Connection': "keep-alive",
    'Host': "m.48.cn",
    'Sec-Fetch-Dest': "script",
    'Sec-Fetch-Mode': "no-cors",
    'Sec-Fetch-Site': "same-site",
    'User-Agent': "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36"}
OCR_HEADERS = {'Authorization': 'APPCODE ',
               'Content-Type': 'application/json; charset=UTF-8'}


class getConfigs:

    def __init__(self, filePath):
        config = configparser.ConfigParser()
        config.read(filePath, encoding='utf-8')
        self.config = config

    def timeConfigs(self):
        auto = int(self.config.get('delay', 'auto'))
        ticketDelay = float(self.config.get('delay', 'ticketDelay'))
        proxyDelay = float(self.config.get('delay', 'proxyDelay'))
        loopDelay = int(self.config.get('delay', 'loopDelay'))
        return (auto, ticketDelay, proxyDelay, loopDelay)

    def betaConfigs(self):
        msMode = self.config.get('beta', 'msMode')
        timeout = self.config.get('beta', 'timeout')
        return (msMode, timeout)

    def proxiesConfigs(self):
        useProxies = int(self.config.get('proxies', 'proxiesSetting'))
        fixedProxies = self.config.get('proxies', 'FixedProxiesIp')
        return (
            useProxies, fixedProxies)

    def ticketsConfigs(self):
        showId = self.config.get('ticketDetails', 'link').split(',')
        num = self.config.get('ticketDetails', 'num').split(',')
        seattype = self.config.get('ticketDetails', 'seattype').split(',')
        walletPwds = self.config.get('ticketDetails', 'walletPwd').split(',')
        brandId = self.brandMapping(self.config.get('ticketDetails', 'brandId').split(','))
        return (showId, num, seattype, walletPwds, brandId)

    def goodsConfigs(self):
        goodsId = self.config.get('goodsDetails', 'link').split(',')
        goodsBrandId = self.brandMapping(self.config.get('goodsDetails', 'brandId').split(','))
        goodNum = self.config.get('goodsDetails', 'goodNum').split(',')
        attrId = self.config.get('goodsDetails', 'attrId').split(',')
        addressID = self.config.get('goodsDetails', 'addressID').split(',')
        lgsId = self.config.get('goodsDetails', 'lgsId').split(',')
        province = self.config.get('goodsDetails', 'province').split(',')
        city = self.config.get('goodsDetails', 'city').split(',')
        return (goodsId, goodsBrandId, goodNum, attrId, addressID, lgsId, province, city)

    def bidConfigs(self):
        bidId = self.config.get('bidDetails', 'link').split('/')[-1]
        priceLimit = int(self.config.get('bidDetails', 'priceLimit'))
        pos = int(self.config.get('bidDetails', 'position'))
        brandIdBid = self.brandMapping(self.config.get('bidDetails', 'brandId'))
        increment = int(self.config.get('bidDetails', 'increment'))
        ocrAppcode = self.config.get('bidDetails', 'ocrAppcode')
        return (bidId, priceLimit, pos, brandIdBid, increment, ocrAppcode)

    def loginConfigs(self):
        user = self.config.get('loginInformation', 'user').split(',')
        pw = self.config.get('loginInformation', 'password').split(',')
        return (user, pw)

    def brandMapping(self, brandList):
        numBrandList = []
        for b in brandList:
            s = str(b)
            r = 0
            if s == 'GNZ':
                r = 3
            else:
                if s == 'SNH':
                    r = 1
                else:
                    if s == 'BEJ':
                        r = 2
                    else:
                        if s == 'CKG':
                            r = 5
            numBrandList.append(r)

        return numBrandList


class getProxy:

    def __init__(self, useProxies, fixedProxies, wanbianAppid=None, wanbianAppkey=None):
        self.useProxies = useProxies
        self.wanbianAppid = wanbianAppid
        self.wanbianAppkey = wanbianAppkey
        self.fixedProxies = fixedProxies
        self.proxyPoolRedisUrl = 'http://localhost:5555/random'
        self.checkIpUrl = 'https://ifconfig.co/'
        self.wanbianUrl = 'http://ip.ipjldl.com/index.php/api/entry?'
        self.wanbianData = {
            'method': "'proxyServer.tiqu_api_url'",
            'packid': 0,
            'fa': 0,
            'dt': "''",
            'groupid': 0,
            'fetch_key': "''",
            'qty': 1,
            'time': 2,
            'port': 1,
            'format': "'txt'",
            'ss': 1,
            'css': "''",
            'pro': "''",
            'city': "''",
            'usertype': 6}
        self.wanbianGetWlUrl = 'https://www.wanbianip.com/Users-whiteIpListNew.html?'
        self.wanbianAddWlUrl = 'https://www.wanbianip.com/Users-whiteIpAddNew.html?'
        self.wanbianDelWlUrl = 'https://www.wanbianip.com/Users-whiteIpDelNew.html?'
        self.wanbianBalWlUrl = 'https://www.wanbianip.com/Users-getBalanceNew.html?'

    def getProxyFromWanbian(self):
        url = self.getDataSumUrl(self.wanbianData, self.wanbianUrl)
        proxies = {'http': '', 'https': ''}
        if self.useProxies == 1:
            if self.fixedProxies == '':
                logger('[MESSAGE] Get proxies from wanbian...')
                while proxies['http'] == '' or proxies['http'] == None:
                    proxies = self.getProxyInLoop(url)
                    proxies = self.proxyInDict(proxies)

                return proxies
            logger('[MESSAGE] Use fixed proxies...')
            return self.proxyInDict(self.fixedProxies)
        else:
            logger('[MESSAGE] Execute without proxies...')
            return proxies

    def getDataSumUrl(self, dataDict, baseUrl):
        dataSum = ''
        for key, item in dataDict.items():
            dataSum = dataSum + '&' + key + '=' + str(item)

        url = baseUrl + dataSum
        return url

    def getProxyFromPool(self, poolUrl):
        try:
            response = requests.get(poolUrl)
            if response.status_code == 200:
                return response.text
        except Exception:
            return

    def getProxyInLoop(self, poolUrl):
        temp = self.getProxyFromPool(poolUrl)
        if temp is not None:
            logger('[SUCCESS] Get proxies successfully. The proxy settings is', temp)
            return temp
        logger('[FAIL] Fail to get proxies.')
        return

    def proxyInDict(self, s):
        proxiesDict = {'http': s,
                       'https': s}
        return proxiesDict

    def getMyIp(self):
        res = requests.get((self.checkIpUrl), verify=False)
        if res.status_code == 200:
            soup = BeautifulSoup(res.text, 'html.parser')
            ip = soup.find('code', {'class': 'ip'}).text
            logger('[SUCCESS] Get local ip:', ip)
            return ip
        logger('[FAIL] Fail to get local ip')
        return False

    def addWhitelistWanbian(self):
        logger('[MESSAGE] Try to add local ip to wanbian whitelist')
        if self.wanbianAppid != '' and self.wanbianAppkey != '':
            data = {'appid': self.wanbianAppid, 'appkey': self.wanbianAppkey}
            try:
                res = requests.get((self.getDataSumUrl(data, self.wanbianBalWlUrl)), verify=False)
                bal = json.loads(res.text)['data']
                logger('[MESSAGE] Getting current balance in wanbian, the balance is:', bal)
                res = requests.get((self.getDataSumUrl(data, self.wanbianGetWlUrl)), verify=False)
                currentWhitelist = json.loads(res.text)['data']
                logger('[MESSAGE] Getting current whitelist in wanbian, the current whitelist is:', currentWhitelist)
                for ip in currentWhitelist:
                    data['whiteip'] = ip
                    res = requests.get((self.getDataSumUrl(data, self.wanbianDelWlUrl)), verify=False)
                    logger('[MESSAGE] Empting the whitelist, the result is:', res.text)

                data['whiteip'] = self.getMyIp()
                res = requests.get((self.getDataSumUrl(data, self.wanbianAddWlUrl)), verify=False)
                logger('[MESSAGE] Adding local ip to whitelist, the result is:', res.text, '\n')
            except Exception:
                logger('[MESSAGE] Fail to add local ip to wanbian whitelist. Execute without add whitelist\n')

        else:
            logger('[FAIL] appid and appkey are not exist. Execute without add whitelist\n')


class login:

    def __init__(self, user, pw, ses, proxies, msMode):
        self.loginHeaders = LOGIN_HEADERS
        self.shopHeaders = SHOP_HEADERS
        self.mHeaders = M_HEADERS
        self.shopUrl = 'https://shop.48.cn/'
        self.mUrl = 'https://m.48.cn/'
        self.loginUrl = 'https://user.48.cn/QuickLogin/login/'
        self.user = user
        self.pw = pw
        self.ses = ses
        self.proxies = proxies
        self.msMode = msMode

    def loginInLoop(self):
        aStatus = False
        while aStatus == False:
            aStatus = self.login()
            if aStatus == False:
                logger('[MESSAGE] Try to login again after 5 seconds.')
                time.sleep(5)

    def login(self):
        logger('[MESSAGE] Try to login as', self.user)
        desc = self.loginPostUrl()
        srcs = self.descHandler(desc)
        self.shopLoginPostUrl(srcs)
        if self.checkShopStatus(self.msMode) == True:
            logger('[SUCCESS] Login status check success.')
            return True
        logger('[FAIL] Login status check fail.')
        return False

    def checkShopStatus(self, domin):
        if domin == 'm':
            logger('[MESSAGE] Check login status at domin', self.mUrl)
            res, self.proxies = requestUrl(self.ses, self.mUrl, '', self.mHeaders, self.proxies, 'get', False)
            soup = BeautifulSoup(res.text, 'html.parser')
            a = soup.find('a', {'class': 'iconfont_s con_enter fs26'})
            if a != None:
                return True
        else:
            logger('[MESSAGE] Check login status at domin', self.shopUrl)
            res, self.proxies = requestUrl(self.ses, self.shopUrl, '', self.shopHeaders, self.proxies, 'get', False)
            soup = BeautifulSoup(res.text, 'html.parser')
            a = soup.find('a').text
            if a[:2] == '你好':
                return True
        return False

    def loginPostUrl(self):
        data = {'phone': '""',
                'phonecode': '""',
                'login_type': '""',
                'area': '""',
                'preg': '""',
                'username': self.user,
                'password': self.pw}
        res, self.proxies = requestUrl(self.ses, self.loginUrl, data, self.loginHeaders, self.proxies, 'post', False)
        if res.status_code == 200:
            logger('[MESSAGE] Post login request successfully.')
            j = json.loads(res.text)['desc']
            return j
        logger('[MESSAGE] Fail to post login request.')
        logger(logger(res.text))

    def shopLoginPostUrl(self, srcs):
        srckeys = [
            self.shopUrl, self.mUrl]
        for src in srcs:
            if src[:16] in srckeys or src[:19] in srckeys:
                ts = getTs()
                url = src + '&_=' + str(ts)
                res, self.proxies = requestUrl(self.ses, url, '', self.shopHeaders, self.proxies, 'get', False)

    def descHandler(self, desc):
        soup = BeautifulSoup(desc, 'html.parser')
        scripts = soup.find_all('script')
        srcs = []
        for script in scripts:
            srcs.append(script['src'])

        return srcs


class buyTicket:

    def __init__(self, ses, proxies, walletPwd=None, showId=None, num=None, seattype=None, brandId=None, msMode='m'):
        if msMode == 'm':
            self.shopHeaders = M_HEADERS
            self.ticketPostUrl = 'https://m.48.cn/TOrder/add'
            self.ticketStatusUrl = 'https://m.48.cn/torder/GetData?pageindex=1&pagesize=15&order_status=-1&seldate=30'
            self.ticketWaitUrl = 'https://m.48.cn/TOrder/wait'
        else:
            self.shopHeaders = SHOP_HEADERS
            self.ticketPostUrl = 'https://shop.48.cn/TOrder/ticket_Add'
            self.ticketWaitUrl = 'https://shop.48.cn/TOrder/wait'
        if walletPwd != None:
            self.walletPwd = hashlib.md5(walletPwd.encode(encoding='UTF-8')).hexdigest()
        self.ses = ses
        self.proxies = proxies
        self.showId = showId
        self.num = num
        self.seattype = seattype
        self.brandId = brandId

    def buyloop(self, accName, lock):
        """
        accName: str the account name of session for log result
        """
        loopCount = 0
        while 1:
            a = time.time()
            if loopCount == 0:
                buyFlag = self.buyTicket()
                loopCount += 1
            else:
                if loopCount != 0 and loopCount <= 10:
                    buyFlag = self.buyTicket(True)
                else:
                    logger('[MESSAGE] Wait ticket function executed 10 times, ending process...')
                    break
            b = time.time() - a
            c = 10 - b
            if c > 0:
                logger('[MESSAGE] Wait', c, 'seconds to wait ticket')
                time.sleep(c)

        lock.release()

    def orderResultHandle(self, d):
        try:
            code = ''
            status = d['HasError']
            if status == False:
                code = 'success'
            else:
                code = d['ErrorCode']
            return code
        except Exception as e:
            try:
                return e
            finally:
                e = None
                del e

    def buyTicket(self, wait=False):
        dictResult = self.buyTicketPostUrl(wait)
        logger('[MESSAGE] Order sent at', datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f'))
        resultCode = self.orderResultHandle(dictResult)
        if resultCode == 'success':
            logger('[SUCCESS] Order sent successfully. The id of the show is', self.showId)
            return True
        logger('[FAIL] Fail to order ticket, the error code is', resultCode, ', with error massage as', dictResult)
        return False

    def buyTicketPostUrl(self, wait=False):
        r = random.random()
        if wait == False:
            url = self.ticketPostUrl
            data = {'ticketsid': self.showId, 'num': self.num, 'seattype': self.seattype, 'brand_id': self.brandId,
                    'choose_times_end': -1, 'ticketstype': 2, 'r': r}
        else:
            if wait == True:
                url = self.ticketWaitUrl
                data = {'id': self.showId, 'num': 1, 'seattype': self.seattype, 'brand_id': self.brandId,
                        'pwd': self.walletPwd, 'r': r}
        res, self.proxies = requestUrl(self.ses, url, data, self.shopHeaders, self.proxies, 'post', False)
        j = resHandler(res.text)
        return j


class buyGood:

    def __init__(self, ses, proxies, goodsId=None, goodsBrandId=None, goodNum=None, attrId=None, addressID=None,
                 lgsId=None, province=None, city=None, msMode='m'):
        if msMode == 'm':
            self.shopHeaders = M_HEADERS
            self.ticketPostUrl = 'https://m.48.cn/TOrder/add'
            self.goodsLimitUrl = 'https://m.48.cn/order/limited'
            self.goodsGetFareNew = 'https://m.48.cn/order/getFareNew'
            self.goodsAddPostUrl = 'https://m.48.cn/order/buy'
            self.goodsBuyPostUrl = 'https://m.48.cn/Order/BuySaveForGive'
            self.ticketRootUrl = 'https://m.48.cn/tickets/item/'
            self.ticketStatusUrl = 'https://m.48.cn/torder/GetData?pageindex=1&pagesize=15&order_status=-1&seldate=30'
            self.ticketWaitUrl = 'https://m.48.cn/TOrder/wait'
        else:
            self.shopHeaders = SHOP_HEADERS
            self.ticketPostUrl = 'https://shop.48.cn/TOrder/add'
            self.goodsLimitUrl = 'https://shop.48.cn/order/limited'
            self.goodsGetFareNew = 'https://shop.48.cn/order/getFareNew'
            self.goodsAddPostUrl = 'https://shop.48.cn/order/buy'
            self.goodsBuyPostUrl = 'https://shop.48.cn/Order/BuySaveForGive'
            self.ticketRootUrl = 'https://shop.48.cn/tickets/item/'
            self.ticketStatusUrl = 'https://shop.48.cn/torder/GetData?pageindex=1&pagesize=15&order_status=-1&seldate=30'
            self.ticketWaitUrl = 'https://shop.48.cn/TOrder/wait'
        self.ses = ses
        self.proxies = proxies
        self.goodsId = goodsId
        self.goodsBrandId = goodsBrandId
        self.addressID = addressID
        self.attrId = attrId
        self.goodNum = goodNum
        self.lgsId = lgsId
        self.province = province
        self.city = city

    def goodloop(self, accName, lock):
        """
        accName: str the account name of session for log result
        """
        loopCount = 0
        while True:
            buyFlag = self.buyGoods()
            if buyFlag == False:
                loopCount += 1
                if loopCount >= 5:
                    logger('[MESSAGE] Executed 5 times on account of', accName, ', sleep 10 seconds before next try')
                    time.sleep(10)
                    loopCount = 0
                else:
                    ldr = loopDelayRand()
                    logger('[FAIL] Execute result is', buyFlag, ', sleep', ldr,
                           'seconds before next try. Account name is', accName)
                    time.sleep(ldr)
            else:
                logger('[SUCCESS] Execute result is', buyFlag, ', thread ended. Account name is', accName)
                break

        lock.release()

    def orderResultHandle(self, d):
        try:
            code = ''
            status = d['HasError']
            if status == False:
                code = 'success'
            else:
                code = d['ErrorCode']
            return code
        except Exception as e:
            try:
                return e
            finally:
                e = None
                del e

    def buyGoods(self):
        orderLimitResult = self.orderLimited()
        resultCode = self.orderResultHandle(orderLimitResult)
        if resultCode != 'success':
            logger('[FAIL] Goods order fail to deliver. Failure details are:')
            logger(orderLimitResult)
            return False
        pageContent = self.addToCart()
        goodsElem = self.goodsOrderPageHandle(pageContent)
        goodsElem = self.getFare(goodsElem)
        dictResult = self.buyGoodsPostUrl(goodsElem)
        logger('[MESSAGE] Order sent at', datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f'))
        resultCode = self.orderResultHandle(dictResult)
        if resultCode == 'success':
            logger('[SUCCESS] Goods order sent successfully')
            return True
        logger('[FAIL] Goods order fail to deliver. Failure details are:', dictResult)
        return False

    def orderLimited(self):
        data = {'goods_id': self.goodsId,
                'attr_id': self.attrId, 'num': self.goodNum, 'isLoadCardNum': 'true', 'brand_id': self.goodsBrandId}
        res, self.proxies = requestUrl(self.ses, self.goodsLimitUrl, data, self.shopHeaders, self.proxies, 'post',
                                       False)
        j = resHandler(res.text)
        return j

    def addToCart(self):
        data = {'num': self.goodNum,
                'donatenum': 0, 'goods_id': self.goodsId, 'ext_id': 0, 'attr_id': self.attrId}
        res, self.proxies = requestUrl(self.ses, self.goodsAddPostUrl, data, self.shopHeaders, self.proxies, 'post',
                                       False)
        pageContent = res.text
        return pageContent

    def goodsOrderPageHandle(self, pageContent):
        temp = {}
        try:
            soup = BeautifulSoup(pageContent, 'html.parser')
            elems = soup.find_all('input')
        except Exception:
            return temp
        else:
            for elem in elems:
                try:
                    temp[elem['id']] = elem['value']
                except Exception:
                    pass

            return temp

    def getFare(self, d):
        try:
            data = {'page_source': d['page_source'], 'cart_id': '',
                    'goods_id': d['goods_id'],
                    'attr_id': d['attr_id'],
                    'num': d['num'],
                    'province': self.province,
                    'city': self.city,
                    'lgs_id': self.lgsId}
            res, self.proxies = requestUrl(self.ses, self.goodsGetFareNew, data, self.shopHeaders, self.proxies, 'post',
                                           False)
            j = resHandler(res.text)
            fare = j['fare']
            d['shipping_fee'] = fare
            d['IsIntegralOffsetFreight'] = 'false'
            d['sumPayPrice'] = float(d['goods_amount']) + float(fare)
            return d
        except Exception:
            return d

    def buyGoodsPostUrl(self, goodsElem):
        r = random.random()
        data = {
            'AddressID': "''",
            'goods_amount': "''",
            'shipping_fee': "''",
            'goods_id': "''",
            'attr_id': "''",
            'num': "''",
            'sumPayPrice': "''",
            'is_inv': "''",
            'lgs_id': "''",
            'integral': "''",
            'invoice_type': "''",
            'invoice_title': "''",
            'invoice_price': "''",
            'CompanyName': "''",
            'TaxpayerID': "''",
            'CompanyAddress': "''",
            'CompanyPhone': "''",
            'CompanyBankOfDeposit': "''",
            'CompanyBankNo': "''",
            'rule_goodslist_content': "''",
            'radom_rule_goodslist_content': "''",
            'remark': "''",
            'IsIntegralOffsetFreight': "''",
            'ruleGoodsContent': "''",
            'ruleGoodsContentSign': "''",
            'r': 'r'}
        data['AddressID'] = self.addressID
        data['lgs_id'] = self.lgsId
        data['is_inv'] = 'false'
        data['invoice_title'] = 'anon'
        data['invoice_price'] = '0'
        keys = data.keys()
        for key in keys:
            try:
                data[key] = goodsElem[key]
            except Exception:
                continue

        res, self.proxies = requestUrl(self.ses, self.goodsBuyPostUrl, data, self.shopHeaders, self.proxies, 'post',
                                       False)
        j = resHandler(res.text)
        return j


class bid:

    def __init__(self, ses, proxies, bidId, priceLimit, pos, brandIdBid, increment, ocrAppcode, msMode):
        if msMode == 'm':
            self.shopHeaders = M_HEADERS
            self.checkUserUrl = 'https://m.48.cn/pai/CheckUserInfo/'
            self.bidPost = 'https://m.48.cn/pai/ToBids/'
            self.checkPricesUrl = 'https://m.48.cn/pai/GetShowBids'
            self.getImageUrl = 'https://m.48.cn/VerifyCode/VerificationCodeImage'
            self.checkImageUrl = 'https://m.48.cn/VerifyCode/VerificationCheck'
        else:
            self.shopHeaders = SHOP_HEADERS
            self.checkUserUrl = 'https://shop.48.cn/pai/CheckUserInfo/'
            self.bidPost = 'https://shop.48.cn/pai/ToBids/'
            self.checkPricesUrl = 'https://shop.48.cn/pai/GetShowBids'
            self.getImageUrl = 'https://shop.48.cn/VerifyCode/VerificationCodeImage'
            self.checkImageUrl = 'https://shop.48.cn/VerifyCode/VerificationCheck'
        self.msMode = msMode
        self.bidId = bidId
        self.shopHeaders['Referer'] = 'https://shop.48.cn/pai/item/' + str(self.bidId)
        self.priceLimit = priceLimit
        self.pos = pos
        self.brandIdBid = brandIdBid
        self.increment = increment
        self.ses = ses
        self.proxies = proxies
        self.sleeptimeForBid = 0.2
        self.ocrUrl = 'http://tysbgpu.market.alicloudapi.com/api/predict/ocr_general'
        OCR_HEADERS['Authorization'] = 'APPCODE ' + ocrAppcode
        self.ocrHeaders = OCR_HEADERS

    def bid(self):
        cStatus = True
        while cStatus == True:
            j = self.checkUser()
            cStatus = j['retValue']['HasError']
            if cStatus == True:
                logger('[FAIL] Bid user info check fail.', j)
                try:
                    depositStatus = str(j['retValue']['Message'])
                    if depositStatus == '':
                        break
                except Exception:
                    pass

                tempInput = str(input('[INPUT-NEEDED] Press c to continue'))
                if tempInput == 'c':
                    break
                time.sleep(self.sleeptimeForBid)

        logger('[MESSAGE] Bid user info check ended.')
        myPrice = 0
        successPrice = 0
        methodFlag = 0
        while 1:
            bidDict = {'list': []}
            for page in range(1, 100):
                temp = self.getBidHistory(page)
                if len(temp['list']) != 0:
                    bidDict['list'].extend(temp['list'])
                    if temp['list'][-1]['bid_amt'] < successPrice:
                        logger('[MESSAGE] Stop to get historical bid prices after page', page)
                        break
                    ldr = loopDelayRand()
                    time.sleep(ldr)
                    # logger('[MESSAGE] Sleep ', ldr, 'seconds to get price in next page')
                else:
                    logger('[MESSAGE] Reach the end of historical prices at page', page - 1)
                    break

            time.sleep(self.sleeptimeForBid)
            currentPrice = self.getCurrentPrice(bidDict)
            if currentPrice != False:
                logger('[MESSAGE] Get current price as', currentPrice, 'at position', self.pos)
            else:
                logger('[MESSAGE] Error occured when trying to handle bidDict, try to get price again')
                continue
            if successPrice < currentPrice:
                if currentPrice - successPrice > self.increment:
                    myPrice = currentPrice + random.randint(2, self.increment)
                else:
                    myPrice = currentPrice + self.increment
                while myPrice > self.priceLimit:
                    self.priceLimit = self.setNewPrice()

                logger('[MESSAGE] Set new price as', myPrice, '\n\n')

    def postWithImageCode(self, amt):
        bidRes = False
        while bidRes == False:
            data = {'id': int(self.bidId)}
            if self.msMode == 'm':
                res, self.proxies = requestUrl(self.ses, self.getImageUrl, data, self.shopHeaders, self.proxies,
                                               'paraGet', False)
            else:
                res, self.proxies = requestUrl(self.ses, self.getImageUrl, data, self.shopHeaders, self.proxies,
                                               'paraPost', False)
            try:
                res = eval(res.text)
                imgBase64 = res['result'].split(',')[-1]
                imgMsg = res['msg']
                pattern = re.compile('[【](.*)[】]')
                msg = re.findall(pattern, imgMsg)
                msg = msg[0]
            except Exception as e:
                try:
                    logger('[MESSAGE] Failure occured when handling imgdata form 48. Error message is', e)
                    continue
                finally:
                    e = None
                    del e

            logger('[MESSAGE] Get image successfully, the img word msg is', msg)
            ocrRes = self.getOcrResults(imgBase64)
            if ocrRes != False:
                wordsPos = self.getPositionFromOcr(msg, ocrRes)
                if wordsPos != False:
                    data = {'code': str(wordsPos).replace(' ', ''),
                            'id': int(self.bidId),
                            'amt': int(amt),
                            'num': 1}
                    res, self.proxies = requestUrl(self.ses, self.checkImageUrl, data, self.shopHeaders, self.proxies,
                                                   'paraPost', False)
                    bidRes = resHandler(res.text)
                    logger('[MESSAGE] Image code bidding result is,', bidRes)
                    try:
                        if bidRes['status'] == 'error':
                            bidRes = False
                    except Exception as e:
                        try:
                            bidRes = False
                        finally:
                            e = None
                            del e

            else:
                logger('[MESSAGE] ocrRes is False, error details are', ocrRes)

        return bidRes

    def getOcrResults(self, imgBase64):
        ocrData = {'image': imgBase64,
                   'configure': {
                       'min_size': 20,
                       'output_prob': True,
                       'output_keypoints': False,
                       'skip_detection': False,
                       'without_predicting_direction': False,
                       'language': "'sx'"}}
        try:
            ocrDataJson = json.dumps(ocrData)
            res, self.proxies = requestUrl(self.ses, self.ocrUrl, ocrDataJson, self.ocrHeaders, self.proxies, 'post',
                                           False)
            j = resHandler(res.text)
            if j['success'] == True:
                return j['ret']
            return False
        except Exception as e:
            try:
                logger('[MESSAGE] Failure occured when trying to get ocr results. Error message is', e)
                return False
            finally:
                e = None
                del e

    def getPositionFromOcr(self, words, ocrRes):
        wordsPos = []
        for word in words:
            for ocr in ocrRes:
                ocrWord = ocr['word']
                if word in ocrWord:
                    rect = ocr['rect']
                    left = rect['left']
                    width = rect['width']
                    top = rect['top']
                    height = rect['height']
                    if len(ocrWord) == 1:
                        x = left + width / 2
                        y = top + height / 2
                    else:
                        partWidth = width / len(ocrWord)
                        partHeight = height / len(ocrWord)
                        inx = ocrWord.find(word) + 1
                        x = left + partWidth * inx / 2
                        y = top + partHeight * inx / 2
                    temp = {'_X': int(x),
                            '_Y': int(y)}
                    wordsPos.append(temp)

        if len(wordsPos) == len(words):
            return wordsPos
        return False

    def checkUser(self):
        j = False
        while j == False:
            r = random.random()
            data = {'id': self.bidId,
                    'brand_id': self.brandIdBid,
                    'r': r}
            res, self.proxies = requestUrl(self.ses, self.checkUserUrl, data, self.shopHeaders, self.proxies, 'post',
                                           False)
            j = resHandler(res.text)

        return j

    def postNewPrice(self, np):
        j = False
        while j == False:
            r = random.random()
            data = {'id': self.bidId,
                    'amt': np,
                    'num': 1,
                    'code': '',
                    'r': r}
            res, self.proxies = requestUrl(self.ses, self.bidPost, data, self.shopHeaders, self.proxies, 'post', False)
            j = resHandler(res.text)

        return j

    def setNewPrice(self):
        try:
            newPrice = int(input('[INPUT-NEEDED] The bid price is over limit ,enter a new price to proceed bidding:'))
            return newPrice
        except Exception:
            logger('[MESSAGE] Invaild input')
            self.setNewPrice()

    def getBidHistory(self, pageNum):
        j = False
        while j == False:
            r = random.random()
            data = {'id': self.bidId, 'numPerPage': 20, 'pageNum': pageNum, 'r': r}
            res, self.proxies = requestUrl(self.ses, self.checkPricesUrl, data, self.shopHeaders, self.proxies,
                                           'paraPost', False)
            j = resHandler(res.text)

        return j

    def getCurrentPrice(self, d):
        bidData = d['list']
        bidList = []
        lastPrice = 0
        for i in range(0, len(bidData)):
            temp = bidData[i]
            if temp['auction_status'] == 1:
                bidList.append(temp['bid_amt'])

        try:
            if len(bidList) >= self.pos:
                lastPrice = bidList[self.pos - 1]
            else:
                lastPrice = bidList[-1]
            logger('[MESSAGE] Total valid prices number is', len(bidList))
            return lastPrice
        except Exception:
            return False


def loopDelayRand():
    r = round(random.random() * LOOP_DELAY / 10, 2)
    return r


def resHandler(txt):
    try:
        j = json.loads(txt)
        return j
    except Exception:
        soup = BeautifulSoup(txt, 'html.parser')
        tempCheckRes = check503(soup)
        ldr = loopDelayRand()
        logger('[MESSAGE] Sleep ', ldr, 'seconds to try agian')
        time.sleep(ldr)
        return False


def requestUrl(ses, url, data, headers, proxies, func='post', changeIp=True):
    resStatus = True
    while resStatus == True:
        if changeIp == True:
            proxies = getProxy(USE_PROXIES, FIXED_PROXIES).getProxyFromWanbian()
        try:
            if func == 'post':
                response = ses.post(url=url, data=data, headers=headers, verify=False, timeout=TIMEOUT)
            else:
                if func == 'paraGet':
                    response = ses.get(url=url, params=data, headers=headers, verify=False, timeout=TIMEOUT)
                else:
                    if func == 'paraPost':
                        response = ses.post(url=url, params=data, headers=headers, verify=False, timeout=TIMEOUT)
                    else:
                        if func == 'get':
                            response = ses.get(url=url, headers=headers, verify=False, timeout=TIMEOUT)
            if response.status_code == 200:
                resStatus == False
                return (
                    response, proxies)
        except Exception:
            logger('[FAIL] Requests failure. Change proxies and try again.')
            changeIp = True


def getOrdertimeWeb(ordertime, proxies, msMode):
    if msMode == 'm':
        url = 'https://m.48.cn//pai/GetTime?' + str(getTs())
    else:
        url = 'https://shop.48.cn//pai/GetTime?' + str(getTs())
    res = requests.get(url, headers=SHOP_HEADERS, proxies=proxies, verify=False, timeout=TIMEOUT)
    try:
        urltime = int(re.sub('[^0-9]', '', res.text))
        endtime = getTs(ordertime)
        difference_time = -300
        nowtime = getTs() + difference_time
        remain = endtime - nowtime
        logger('[SUCCESS] Get remain time successfully. Server time is', tsDate(urltime), '\nNowtime is',
               tsDate(nowtime), ',', remain / 1000, 'seconds remained')
        return remain
    except Exception:
        logger('[FAIL] Fail to get remain time')
        return False


def tsDate(t):
    t = round(t / 1000)
    local = time.localtime(t)
    dt = time.strftime('%Y-%m-%d %H:%M:%S', local)
    return dt


def getTs(t=None):
    if t == None:
        t = time.time()
    else:
        timeArray = time.strptime(t, '%Y-%m-%d %H:%M:%S.%f')
        timestamp = time.mktime(timeArray)
        t = timestamp
    ts = int(round(t * 1000))
    return ts


def countdown(ordertime, leadtime):
    temp = datetime.datetime.strptime(ordertime, '%Y-%m-%d %H:%M:%S.%f')
    lead = datetime.timedelta(seconds=(int(leadtime)))
    loginTime = temp - lead
    loginTime = loginTime.strftime('%Y-%m-%d %H:%M:%S.%f')
    while True:
        now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
        if now > loginTime:
            print('Countdown end at', now)
            break
        print('Counting down', now)
        time.sleep(0.01)


def getTime():
    tStatus = False
    while tStatus == False:
        ordertime = input(
            "[INPUT-NEEDED] Input order time (in the format at 2020-12-12 19:30:00.00000), Leave empty to use default setting (today's 20:30) :")
        if ordertime == '':
            ordertime = datetime.datetime.now().strftime('%Y-%m-%d') + ' ' + '20:30:00.00000'
        try:
            datetime.datetime.strptime(str(ordertime), '%Y-%m-%d %H:%M:%S.%f')
            tStatus = True
        except Exception:
            logger('[FAIL] Input error occurred, enter again.')
            tStatus = False

    logger('[SUCCESS] Set order time as', ordertime, '\n')
    return ordertime


def logger(*items):
    stringSum = ''
    file = open(LOG_PATH, 'a')
    for item in items:
        stringSum = stringSum + ' ' + str(item)

    print(stringSum)
    logTime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-2]
    file.write(logTime + '   ' + stringSum + '\n')
    file.close()


def getFunc():
    func = ''
    funcList = ['b', 'c', 'd']
    while func not in funcList:
        func = input(
            '[INPUT-NEEDED] Specific a function (b: ticket/ c: bid item/ d: points goods), Leave empty to use default setting (b to order ticket) :')
        if func == '':
            func = 'b'
        func = str(func)

    return func


def saveCookies(path, ses):
    with open(path, 'a') as (f):
        json.dump(requests.utils.dict_from_cookiejar(ses.cookies), f)
        f.write('\n\n')


def loadCookies(path, ses, indexForCookies):
    with open(path, 'r') as (f):
        data = f.readlines()
        for i in range(len(data) - 1, -1, -1):
            if data[i] == '\n':
                data.pop(i)

        cookies = requests.utils.cookiejar_from_dict(json.loads(data[indexForCookies]))
        ses.cookies.update(cookies)


def check503(soup):
    lzs = soup.find('div', {'class': 'lz_s'})
    try:
        if lzs.text != None:
            logger('[FAIL] Server return 503 because requests too fast, set a higher delay to try again')
            return True
    except Exception:
        pass

    return False


def getLocks(sess):
    locks = []
    for inx in range(0, len(sess)):
        lock = thread.allocate_lock()
        lock.acquire()
        locks.append(lock)

    return locks


def main():
    func = getFunc()
    gb = getConfigs(CONFIGS_PATH)
    USE_PROXIES, FIXED_PROXIES = gb.proxiesConfigs()
    users, pws = gb.loginConfigs()
    msMode, TIMEOUT = gb.betaConfigs()
    auto, ticketDelay, proxyDelay, LOOP_DELAY = gb.timeConfigs()
    proxies = getProxy(USE_PROXIES, FIXED_PROXIES).getProxyFromWanbian()
    ordertime = getTime()
    countdown(ordertime, 30 + random.randint(0, 29))
    sess = []
    for idx in range(0, len(users)):
        ses = requests.session()
        if os.path.exists(COOKIES_PATH) == True:
            loadCookies(COOKIES_PATH, ses, idx)
            logger('[MESSAGE] Cookies loaded, the total number of loaded cookies is', idx + 1)
        else:
            a = login(users[idx], pws[idx], ses, proxies, msMode)
            a.loginInLoop()
        sess.append(ses)

    if func == 'b':
        locks = getLocks(sess)
        showId, num, seattype, walletPwds, brandId = gb.ticketsConfigs()
    else:
        if func == 'c':
            bidId, priceLimit, pos, brandIdBid, increment, ocrAppcode = gb.bidConfigs()
        else:
            if func == 'd':
                locks = getLocks(sess)
                goodsId, goodsBrandId, goodNum, attrId, addressID, lgsId, province, city = gb.goodsConfigs()
    if auto == 0:
        countdown(ordertime, proxyDelay)
        time.sleep(ticketDelay)
    else:
        if auto == 1:
            remain = getOrdertimeWeb(ordertime, proxies, msMode)
            remain = remain / 1000
            if remain > 0 and remain < 600:
                logger('[MESSAGE] Wait', remain, 'seconds + ', ticketDelay, 'seconds')
                time.sleep(remain + ticketDelay)
            else:
                if remain < 0:
                    logger('[MESSAGE] No need to wait, because ordertime was passed')
        for inx in range(len(sess) - 1, -1, -1):
            if func == 'b':
                b = buyTicket(sess[inx], proxies, walletPwds[inx], showId[inx], num[inx], seattype[inx], brandId[inx],
                              msMode)
                thread.start_new_thread(b.buyloop, (users[inx], locks[inx]))
            else:
                if func == 'c':
                    if len(sess) > 1:
                        logger('[MESSAGE] Bid helper is only available for the last account in list, which is',
                               users[inx])
                    c = bid(sess[inx], proxies, bidId, priceLimit, pos, brandIdBid, increment, ocrAppcode, msMode)
                    c.bid()

        if func == 'b' or func == 'd':
            for i in range(len(locks)):
                while locks[i].locked():
                    pass

        logger('[MESSAGE] ALL DONE')
        time.sleep(30)


if __name__ == '__main__':
    main()
